1._ ¿En qué consiste el principio de responsabilidad única?
Consiste en que cada clase debe de ser responsable de una unica parte dentro de la aplicación, 
esta responsabilidad debe ser definida y concreta.

¿Cuál es su propósito?
De que cada clase cumpla un unico proposito y no tenga varias responsabilidades a la vez.

2. ¿Qué características tiene, según su opinión, un “buen” código o código limpio?
Debe tener lo siguiente.
*Estar redactado de forma legible.
*Contener pruebas unitarias.
*Es un codigo simple entendible para posteriores desarrolladore.
*Ser código reusable.

3. Detalla cómo harías todo aquello que no hayas llegado a completar


